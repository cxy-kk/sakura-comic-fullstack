"""
直播功能蓝图
包括直播间管理、弹幕、礼物、关注等功能的 API
"""

from flask import Blueprint, request, jsonify
from datetime import datetime
import uuid
from ..extensions import db
from ..models.models import (
    LiveRoom, LiveCategory, LiveWatchRecord, LiveDanmaku, 
    LiveGift, LiveGiftRecord, LiveStream, LiveFollow, LiveMute, User
)

live_bp = Blueprint('live', __name__, url_prefix='/api/live')


# ==================== 直播间管理 ====================

@live_bp.route('/rooms', methods=['GET'])
def get_live_rooms():
    """获取所有在线直播间列表"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        category_id = request.args.get('category_id', None, type=int)
        
        query = LiveRoom.query.filter_by(status='online')
        
        if category_id:
            query = query.filter_by(category_id=category_id)
        
        rooms = query.paginate(page=page, per_page=per_page)
        
        data = {
            'total': rooms.total,
            'pages': rooms.pages,
            'current_page': page,
            'rooms': [
                {
                    'id': room.id,
                    'room_name': room.room_name,
                    'room_description': room.room_description,
                    'room_cover': room.room_cover,
                    'status': room.status,
                    'viewers_count': room.viewers_count,
                    'likes_count': room.likes_count,
                    'started_at': room.started_at.isoformat() if room.started_at else None,
                    'streamer': {
                        'id': room.user.id,
                        'username': room.user.username,
                        'avatar': room.user.avatar
                    },
                    'stream': {
                        'rtmp_pull_url': room.stream.rtmp_pull_url if room.stream else None,
                        'hls_pull_url': room.stream.hls_pull_url if room.stream else None,
                    } if room.stream else None
                }
                for room in rooms.items
            ]
        }
        
        return jsonify({'code': 200, 'message': 'success', 'data': data})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)}), 500


@live_bp.route('/rooms/<int:room_id>', methods=['GET'])
def get_room_detail(room_id):
    """获取直播间详情"""
    try:
        room = LiveRoom.query.get(room_id)
        
        if not room:
            return jsonify({'code': 404, 'message': 'Room not found'}), 404
        
        data = {
            'id': room.id,
            'room_name': room.room_name,
            'room_description': room.room_description,
            'room_cover': room.room_cover,
            'status': room.status,
            'viewers_count': room.viewers_count,
            'likes_count': room.likes_count,
            'created_at': room.created_at.isoformat() if room.created_at else None,
            'started_at': room.started_at.isoformat() if room.started_at else None,
            'streamer': {
                'id': room.user.id,
                'username': room.user.username,
                'avatar': room.user.avatar,
                'about_me': room.user.about_me
            },
            'category': {
                'id': room.category.id,
                'name': room.category.category_name
            } if room.category else None,
            'stream': {
                'stream_key': room.stream.stream_key if room.stream else None,
                'rtmp_push_url': room.stream.rtmp_push_url if room.stream else None,
                'rtmp_pull_url': room.stream.rtmp_pull_url if room.stream else None,
                'hls_pull_url': room.stream.hls_pull_url if room.stream else None,
                'bitrate': room.stream.bitrate if room.stream else None,
                'resolution': room.stream.resolution if room.stream else None,
                'fps': room.stream.fps if room.stream else None
            } if room.stream else None
        }
        
        return jsonify({'code': 200, 'message': 'success', 'data': data})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)}), 500


@live_bp.route('/rooms', methods=['POST'])
def create_room():
    """创建直播间"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        room_name = data.get('room_name')
        room_description = data.get('room_description', '')
        category_id = data.get('category_id')
        
        if not user_id or not room_name:
            return jsonify({'code': 400, 'message': 'Missing required fields'}), 400
        
        # 检查用户是否存在
        user = User.query.get(user_id)
        if not user:
            return jsonify({'code': 404, 'message': 'User not found'}), 404
        
        # 创建直播间
        room = LiveRoom(
            user_id=user_id,
            room_name=room_name,
            room_description=room_description,
            category_id=category_id,
            status='offline'
        )
        
        db.session.add(room)
        db.session.flush()  # 获取 room.id
        
        # 假设的流媒体服务器地址
        RTMP_SERVER = "rtmp://localhost/live/"
        HLS_SERVER = "http://localhost/hls/"
        
        # 创建直播流配置
        stream_key = str(uuid.uuid4()).replace('-', '')
        
        # 构造推拉流地址 (这里需要根据实际的 Nginx-RTMP 配置来确定)
        rtmp_push_url = f"{RTMP_SERVER}{stream_key}"
        rtmp_pull_url = f"{RTMP_SERVER}{stream_key}"
        hls_pull_url = f"{HLS_SERVER}{stream_key}.m3u8"
        
        stream = LiveStream(
            room_id=room.id,
            stream_key=stream_key,
            rtmp_push_url=rtmp_push_url,
            rtmp_pull_url=rtmp_pull_url,
            hls_pull_url=hls_pull_url
        )
        
        db.session.add(stream)
        db.session.commit()
        
        return jsonify({
            'code': 201,
            'message': 'Room created successfully',
            'data': {
                'id': room.id,
                'room_name': room.room_name,
                'stream_key': stream_key,
            'rtmp_push_url': rtmp_push_url,
            'rtmp_pull_url': rtmp_pull_url,
            'hls_pull_url': hls_pull_url
            }
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'code': 500, 'message': str(e)}), 500


@live_bp.route('/rooms/<int:room_id>/start', methods=['POST'])
def start_live(room_id):
    """开始直播"""
    try:
        room = LiveRoom.query.get(room_id)
        
        if not room:
            return jsonify({'code': 404, 'message': 'Room not found'}), 404
        
        room.status = 'online'
        room.started_at = datetime.utcnow()
        room.viewers_count = 0
        
        db.session.commit()
        
        return jsonify({
            'code': 200,
            'message': 'Live started successfully',
            'data': {'status': room.status}
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'code': 500, 'message': str(e)}), 500


@live_bp.route('/rooms/<int:room_id>/stop', methods=['POST'])
def stop_live(room_id):
    """停止直播"""
    try:
        room = LiveRoom.query.get(room_id)
        
        if not room:
            return jsonify({'code': 404, 'message': 'Room not found'}), 404
        
        room.status = 'offline'
        room.ended_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'code': 200,
            'message': 'Live stopped successfully',
            'data': {'status': room.status}
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'code': 500, 'message': str(e)}), 500


# ==================== 弹幕功能 ====================

@live_bp.route('/rooms/<int:room_id>/danmaku', methods=['GET'])
def get_danmakus(room_id):
    """获取直播间弹幕列表"""
    try:
        limit = request.args.get('limit', 50, type=int)
        
        danmakus = LiveDanmaku.query.filter_by(room_id=room_id)\
            .order_by(LiveDanmaku.created_at.desc())\
            .limit(limit)\
            .all()
        
        data = [
            {
                'id': d.id,
                'content': d.content,
                'color': d.color,
                'font_size': d.font_size,
                'user': {
                    'id': d.user.id,
                    'username': d.user.username,
                    'avatar': d.user.avatar
                },
                'created_at': d.created_at.isoformat()
            }
            for d in danmakus
        ]
        
        return jsonify({'code': 200, 'message': 'success', 'data': data})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)}), 500


@live_bp.route('/rooms/<int:room_id>/danmaku', methods=['POST'])
def send_danmaku(room_id):
    """发送弹幕"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        content = data.get('content')
        color = data.get('color', '#FFFFFF')
        font_size = data.get('font_size', 25)
        
        if not user_id or not content:
            return jsonify({'code': 400, 'message': 'Missing required fields'}), 400
        
        # 检查用户是否被禁言
        mute = LiveMute.query.filter_by(
            room_id=room_id,
            muted_user_id=user_id,
            unmuted_at=None
        ).first()
        
        if mute and (datetime.utcnow() - mute.muted_at).total_seconds() < mute.mute_duration:
            return jsonify({'code': 403, 'message': 'User is muted'}), 403
        
        danmaku = LiveDanmaku(
            room_id=room_id,
            user_id=user_id,
            content=content,
            color=color,
            font_size=font_size
        )
        
        db.session.add(danmaku)
        db.session.commit()
        
        return jsonify({
            'code': 201,
            'message': 'Danmaku sent successfully',
            'data': {'id': danmaku.id}
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'code': 500, 'message': str(e)}), 500


# ==================== 礼物功能 ====================

@live_bp.route('/gifts', methods=['GET'])
def get_gifts():
    """获取礼物列表"""
    try:
        gifts = LiveGift.query.all()
        
        data = [
            {
                'id': g.id,
                'gift_name': g.gift_name,
                'gift_icon': g.gift_icon,
                'gift_price': float(g.gift_price),
                'description': g.description
            }
            for g in gifts
        ]
        
        return jsonify({'code': 200, 'message': 'success', 'data': data})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)}), 500


@live_bp.route('/rooms/<int:room_id>/gift', methods=['POST'])
def send_gift(room_id):
    """赠送礼物"""
    try:
        data = request.get_json()
        sender_id = data.get('sender_id')
        gift_id = data.get('gift_id')
        quantity = data.get('quantity', 1)
        
        if not sender_id or not gift_id:
            return jsonify({'code': 400, 'message': 'Missing required fields'}), 400
        
        room = LiveRoom.query.get(room_id)
        gift = LiveGift.query.get(gift_id)
        
        if not room or not gift:
            return jsonify({'code': 404, 'message': 'Room or gift not found'}), 404
        
        total_price = float(gift.gift_price) * quantity
        
        gift_record = LiveGiftRecord(
            room_id=room_id,
            sender_id=sender_id,
            receiver_id=room.user_id,
            gift_id=gift_id,
            quantity=quantity,
            total_price=total_price
        )
        
        db.session.add(gift_record)
        db.session.commit()
        
        return jsonify({
            'code': 201,
            'message': 'Gift sent successfully',
            'data': {'id': gift_record.id, 'total_price': float(total_price)}
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'code': 500, 'message': str(e)}), 500


# ==================== Nginx-RTMP 回调接口 ====================

@live_bp.route('/callback/<string:action>', methods=['POST'])
def live_callback(action):
    """处理 Nginx-RTMP 的 on_publish, on_done 等回调"""
    # 实际项目中，这里需要验证请求是否来自 Nginx 服务器
    
    stream_key = request.form.get('name')
    client_id = request.form.get('clientid')
    
    if not stream_key:
        return jsonify({'code': 400, 'message': 'Missing stream key'}), 400

    stream = LiveStream.query.filter_by(stream_key=stream_key).first()
    if not stream:
        current_app.logger.warning(f"Callback for unknown stream key: {stream_key}")
        return jsonify({'code': 404, 'message': 'Stream not found'}), 404

    room = LiveRoom.query.get(stream.room_id)
    
    if action == 'on_publish':
        # 推流开始
        room.status = 'online'
        room.started_at = datetime.utcnow()
        room.viewers_count = 0 # 重置观看人数
        db.session.commit()
        current_app.logger.info(f"Stream published: {stream_key}, Room ID: {room.id}")
    elif action == 'on_done':
        # 推流结束
        room.status = 'offline'
        room.ended_at = datetime.utcnow()
        db.session.commit()
        current_app.logger.info(f"Stream stopped: {stream_key}, Room ID: {room.id}")
    else:
        return jsonify({'code': 400, 'message': 'Invalid action'}), 400

    return jsonify({'code': 200, 'message': f'Live callback {action} processed'}), 200


# ==================== 关注功能 ====================

@live_bp.route('/rooms/<int:room_id>/follow', methods=['POST'])
def follow_room(room_id):
    """关注直播间"""
    try:
        data = request.get_json()
        follower_id = data.get('follower_id')
        
        if not follower_id:
            return jsonify({'code': 400, 'message': 'Missing follower_id'}), 400
        
        room = LiveRoom.query.get(room_id)
        if not room:
            return jsonify({'code': 404, 'message': 'Room not found'}), 404
        
        # 检查是否已关注
        existing = LiveFollow.query.filter_by(
            follower_id=follower_id,
            room_id=room_id
        ).first()
        
        if existing:
            return jsonify({'code': 400, 'message': 'Already followed'}), 400
        
        follow = LiveFollow(follower_id=follower_id, room_id=room_id)
        db.session.add(follow)
        db.session.commit()
        
        return jsonify({
            'code': 201,
            'message': 'Followed successfully'
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'code': 500, 'message': str(e)}), 500


@live_bp.route('/rooms/<int:room_id>/unfollow', methods=['POST'])
def unfollow_room(room_id):
    """取消关注直播间"""
    try:
        data = request.get_json()
        follower_id = data.get('follower_id')
        
        if not follower_id:
            return jsonify({'code': 400, 'message': 'Missing follower_id'}), 400
        
        follow = LiveFollow.query.filter_by(
            follower_id=follower_id,
            room_id=room_id
        ).first()
        
        if not follow:
            return jsonify({'code': 404, 'message': 'Follow record not found'}), 404
        
        db.session.delete(follow)
        db.session.commit()
        
        return jsonify({'code': 200, 'message': 'Unfollowed successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'code': 500, 'message': str(e)}), 500


# ==================== 观看记录 ====================

@live_bp.route('/rooms/<int:room_id>/watch', methods=['POST'])
def record_watch(room_id):
    """记录观看"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        watch_duration = data.get('watch_duration', 0)
        
        if not user_id:
            return jsonify({'code': 400, 'message': 'Missing user_id'}), 400
        
        record = LiveWatchRecord(
            user_id=user_id,
            room_id=room_id,
            watch_duration=watch_duration
        )
        
        db.session.add(record)
        db.session.commit()
        
        return jsonify({
            'code': 201,
            'message': 'Watch record created successfully',
            'data': {'id': record.id}
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'code': 500, 'message': str(e)}), 500


# ==================== 直播分类 ====================

@live_bp.route('/categories', methods=['GET'])
def get_categories():
    """获取直播分类列表"""
    try:
        categories = LiveCategory.query.all()
        
        data = [
            {
                'id': c.id,
                'category_name': c.category_name,
                'category_icon': c.category_icon,
                'description': c.description
            }
            for c in categories
        ]
        
        return jsonify({'code': 200, 'message': 'success', 'data': data})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)}), 500


# ==================== 健康检查 ====================

@live_bp.route('/health', methods=['GET'])
def health_check():
    """直播服务健康检查"""
    return jsonify({
        'code': 200,
        'message': 'Live service is running',
        'timestamp': datetime.utcnow().isoformat()
    })


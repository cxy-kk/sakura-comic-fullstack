
from ..extensions import db
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.dialects.mysql import LONGTEXT
import datetime


class MovType(db.Model):
    __tablename__ = 'sakura_movtype'
    type_id = db.Column(db.Integer, primary_key=True)
    type_name = db.Column(db.String(20), nullable=False)
    this_type_movies = db.relationship('MovInfo', back_populates='this_mov_type')
    this_type_movie_details = db.relationship('MovDetail', back_populates='this_mov_type')


class MovInfo(db.Model):
    __tablename__ = 'sakura_movinfo'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    type_id = db.Column(db.Integer, db.ForeignKey('sakura_movtype.type_id'))  # 一对多关系,ForeignKey在多侧
    type_name = db.Column(db.String(20), nullable=False)
    vod_en = db.Column(db.Text, nullable=False)
    vod_id = db.Column(db.Integer, primary_key=True)
    vod_name = db.Column(db.Text, nullable=False)
    vod_play_from = db.Column(db.Text)
    vod_remarks = db.Column(db.Text)
    vod_time = db.Column(db.DateTime)
    this_mov_type = db.relationship('MovType', back_populates='this_type_movies')


class MovDetail(db.Model):
    __tablename__ = 'sakura_movdetail'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    group_id = db.Column(db.Integer)
    type_id = db.Column(db.Integer, db.ForeignKey('sakura_movtype.type_id'))  # 一对多,设置外键
    type_id_1 = db.Column(db.Integer)
    type_name = db.Column(db.String(20))
    vod_actor = db.Column(db.Text)
    vod_area = db.Column(db.Text)
    vod_author = db.Column(db.Text)
    vod_behind = db.Column(db.Text)
    vod_blurb = db.Column(db.Text)
    vod_class = db.Column(db.Text)
    vod_color = db.Column(db.Text)
    vod_content = db.Column(db.Text)
    vod_copyright = db.Column(db.Integer)
    vod_director = db.Column(db.Text)
    vod_douban_id = db.Column(db.Integer)
    vod_douban_score = db.Column(db.String(20))
    vod_down = db.Column(db.Integer)
    vod_down_from = db.Column(db.Text)
    vod_down_note = db.Column(db.Text)
    vod_down_server = db.Column(db.Text)
    vod_down_url = db.Column(db.Text)
    vod_duration = db.Column(db.Text)
    vod_en = db.Column(db.Text)
    vod_hits = db.Column(db.Integer)
    vod_hits_day = db.Column(db.Integer)
    vod_hits_month = db.Column(db.Integer)
    vod_hits_week = db.Column(db.Integer)
    vod_id = db.Column(db.Integer, primary_key=True)
    vod_isend = db.Column(db.Integer)
    vod_jumpurl = db.Column(db.Text)
    vod_lang = db.Column(db.Text)
    vod_letter = db.Column(db.Text)
    vod_level = db.Column(db.Integer)
    vod_lock = db.Column(db.Integer)
    vod_name = db.Column(db.Text)
    vod_pic = db.Column(db.Text)
    vod_pic_screenshot = db.Column(db.Text)
    vod_pic_slide = db.Column(db.Text)
    vod_pic_thumb = db.Column(db.Text)
    vod_play_from = db.Column(db.Text)
    vod_play_note = db.Column(db.Text)
    vod_play_server = db.Column(db.Text)
    vod_play_url = db.Column(LONGTEXT)
    vod_plot = db.Column(db.Integer)
    vod_plot_detail = db.Column(db.Text)
    vod_plot_name = db.Column(db.Text)
    vod_points = db.Column(db.Integer)
    vod_points_down = db.Column(db.Integer)
    vod_points_play = db.Column(db.Integer)
    vod_pubdate = db.Column(db.Text)
    vod_pwd = db.Column(db.Text)
    vod_pwd_down = db.Column(db.Text)
    vod_pwd_down_url = db.Column(db.Text)
    vod_pwd_play = db.Column(db.Text)
    vod_pwd_play_url = db.Column(db.Text)
    vod_pwd_url = db.Column(db.Text)
    vod_rel_art = db.Column(db.Text)
    vod_rel_vod = db.Column(db.Text)
    vod_remarks = db.Column(db.Text)
    vod_reurl = db.Column(db.Text)
    vod_score = db.Column(db.Text)
    vod_score_all = db.Column(db.Integer)
    vod_score_num = db.Column(db.Integer)
    vod_serial = db.Column(db.Text)
    vod_state = db.Column(db.Text)
    vod_status = db.Column(db.Integer)
    vod_sub = db.Column(db.Text)
    vod_tag = db.Column(db.Text)
    vod_time = db.Column(db.DateTime)
    vod_time_add = db.Column(db.Integer)
    vod_time_hits = db.Column(db.Integer)
    vod_time_make = db.Column(db.Integer)
    vod_total = db.Column(db.Integer)
    vod_tpl = db.Column(db.Text)
    vod_tpl_down = db.Column(db.Text)
    vod_tpl_play = db.Column(db.Text)
    vod_trysee = db.Column(db.Integer)
    vod_tv = db.Column(db.Text)
    vod_up = db.Column(db.Integer)
    vod_version = db.Column(db.Text)
    vod_weekday = db.Column(db.Text)
    vod_writer = db.Column(db.Text)
    vod_year = db.Column(db.Text)
    this_mov_type = db.relationship('MovType', back_populates='this_type_movie_details')
    comments = db.relationship('Comment', back_populates='mov_detail', cascade='all, delete-orphan')


class User(db.Model):
    __tablename__ = 'sakura_user'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True)
    email = db.Column(db.String(120), unique=True)
    password_hash = db.Column(db.String(255))
    avatar = db.Column(db.String(200))
    about_me = db.Column(db.Text)
    member_since = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    last_seen = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    comments = db.relationship('Comment', back_populates='user', cascade='all, delete-orphan')
    collections = db.relationship('UserCollection', back_populates='user', cascade='all, delete-orphan')
    live_rooms = db.relationship('LiveRoom', back_populates='user', cascade='all, delete-orphan')
    watch_records = db.relationship('LiveWatchRecord', back_populates='user', cascade='all, delete-orphan')
    danmakus = db.relationship('LiveDanmaku', back_populates='user', cascade='all, delete-orphan')
    gift_records = db.relationship('LiveGiftRecord', back_populates='sender', cascade='all, delete-orphan')
    follows = db.relationship('LiveFollow', back_populates='follower', cascade='all, delete-orphan')
    mutes = db.relationship('LiveMute', back_populates='muted_user', cascade='all, delete-orphan')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def validate_password(self, password):
        return check_password_hash(self.password_hash, password)


class Comment(db.Model):
    __tablename__ = 'sakura_comment'
    id = db.Column(db.Integer, primary_key=True)
    body = db.Column(db.Text)
    reviewed = db.Column(db.Boolean, default=True)
    timestamp = db.Column(db.DateTime, default=datetime.datetime.utcnow, index=True)

    user_id = db.Column(db.Integer, db.ForeignKey('sakura_user.id'))
    replied_id = db.Column(db.Integer, db.ForeignKey('sakura_comment.id'))
    movdetail_id = db.Column(db.Integer, db.ForeignKey('sakura_movdetail.id'))

    user = db.relationship('User', back_populates='comments')
    mov_detail = db.relationship('MovDetail', back_populates='comments')
    replies = db.relationship('Comment', back_populates='replied', cascade='all, delete-orphan')
    replied = db.relationship('Comment', back_populates='replies', remote_side=[id])


class UserCollection(db.Model):
    __tablename__ = 'sakura_user_collection'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('sakura_user.id'))
    movdetail_id_list = db.Column(LONGTEXT)

    user = db.relationship('User', back_populates='collections')


# ==================== 直播功能模型 ====================

class LiveCategory(db.Model):
    __tablename__ = 'sakura_live_category'
    id = db.Column(db.Integer, primary_key=True)
    category_name = db.Column(db.String(100), unique=True, nullable=False)
    category_icon = db.Column(db.String(500))
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    live_rooms = db.relationship('LiveRoom', back_populates='category')


class LiveRoom(db.Model):
    __tablename__ = 'sakura_live_room'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('sakura_user.id'), nullable=False)
    room_name = db.Column(db.String(255), nullable=False)
    room_description = db.Column(db.Text)
    room_cover = db.Column(db.String(500))
    status = db.Column(db.String(20), default='offline')  # offline, online, banned
    category_id = db.Column(db.Integer, db.ForeignKey('sakura_live_category.id'))
    viewers_count = db.Column(db.Integer, default=0)
    likes_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    started_at = db.Column(db.DateTime)
    ended_at = db.Column(db.DateTime)
    updated_at = db.Column(db.DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    user = db.relationship('User', back_populates='live_rooms')
    category = db.relationship('LiveCategory', back_populates='live_rooms')
    watch_records = db.relationship('LiveWatchRecord', back_populates='room', cascade='all, delete-orphan')
    danmakus = db.relationship('LiveDanmaku', back_populates='room', cascade='all, delete-orphan')
    gift_records = db.relationship('LiveGiftRecord', back_populates='room', cascade='all, delete-orphan')
    stream = db.relationship('LiveStream', back_populates='room', uselist=False, cascade='all, delete-orphan')
    follows = db.relationship('LiveFollow', back_populates='room', cascade='all, delete-orphan')
    mutes = db.relationship('LiveMute', back_populates='room', cascade='all, delete-orphan')


class LiveWatchRecord(db.Model):
    __tablename__ = 'sakura_live_watch_record'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('sakura_user.id'), nullable=False)
    room_id = db.Column(db.Integer, db.ForeignKey('sakura_live_room.id'), nullable=False)
    watch_duration = db.Column(db.Integer, default=0)
    watched_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    user = db.relationship('User', back_populates='watch_records')
    room = db.relationship('LiveRoom', back_populates='watch_records')


class LiveDanmaku(db.Model):
    __tablename__ = 'sakura_live_danmaku'
    id = db.Column(db.Integer, primary_key=True)
    room_id = db.Column(db.Integer, db.ForeignKey('sakura_live_room.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('sakura_user.id'), nullable=False)
    content = db.Column(db.String(500), nullable=False)
    color = db.Column(db.String(20), default='#FFFFFF')
    font_size = db.Column(db.Integer, default=25)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    room = db.relationship('LiveRoom', back_populates='danmakus')
    user = db.relationship('User', back_populates='danmakus')


class LiveGift(db.Model):
    __tablename__ = 'sakura_live_gift'
    id = db.Column(db.Integer, primary_key=True)
    gift_name = db.Column(db.String(100), unique=True, nullable=False)
    gift_icon = db.Column(db.String(500))
    gift_price = db.Column(db.Numeric(10, 2), nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    gift_records = db.relationship('LiveGiftRecord', back_populates='gift')


class LiveGiftRecord(db.Model):
    __tablename__ = 'sakura_live_gift_record'
    id = db.Column(db.Integer, primary_key=True)
    room_id = db.Column(db.Integer, db.ForeignKey('sakura_live_room.id'), nullable=False)
    sender_id = db.Column(db.Integer, db.ForeignKey('sakura_user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('sakura_user.id'), nullable=False)
    gift_id = db.Column(db.Integer, db.ForeignKey('sakura_live_gift.id'), nullable=False)
    quantity = db.Column(db.Integer, default=1)
    total_price = db.Column(db.Numeric(10, 2), nullable=False)
    sent_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    room = db.relationship('LiveRoom', back_populates='gift_records')
    sender = db.relationship('User', back_populates='gift_records', foreign_keys=[sender_id])
    receiver = db.relationship('User', foreign_keys=[receiver_id])
    gift = db.relationship('LiveGift', back_populates='gift_records')


class LiveStream(db.Model):
    __tablename__ = 'sakura_live_stream'
    id = db.Column(db.Integer, primary_key=True)
    room_id = db.Column(db.Integer, db.ForeignKey('sakura_live_room.id'), nullable=False, unique=True)
    stream_key = db.Column(db.String(255), unique=True, nullable=False)
    stream_url = db.Column(db.String(500))
    rtmp_url = db.Column(db.String(500))
    hls_url = db.Column(db.String(500))
    bitrate = db.Column(db.Integer, default=2500)
    resolution = db.Column(db.String(20), default='1920x1080')
    fps = db.Column(db.Integer, default=30)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    room = db.relationship('LiveRoom', back_populates='stream')


class LiveFollow(db.Model):
    __tablename__ = 'sakura_live_follow'
    id = db.Column(db.Integer, primary_key=True)
    follower_id = db.Column(db.Integer, db.ForeignKey('sakura_user.id'), nullable=False)
    room_id = db.Column(db.Integer, db.ForeignKey('sakura_live_room.id'), nullable=False)
    followed_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    __table_args__ = (db.UniqueConstraint('follower_id', 'room_id', name='unique_follow'),)

    follower = db.relationship('User', back_populates='follows')
    room = db.relationship('LiveRoom', back_populates='follows')


class LiveMute(db.Model):
    __tablename__ = 'sakura_live_mute'
    id = db.Column(db.Integer, primary_key=True)
    room_id = db.Column(db.Integer, db.ForeignKey('sakura_live_room.id'), nullable=False)
    muted_user_id = db.Column(db.Integer, db.ForeignKey('sakura_user.id'), nullable=False)
    muted_by = db.Column(db.Integer, db.ForeignKey('sakura_user.id'), nullable=False)
    reason = db.Column(db.String(500))
    mute_duration = db.Column(db.Integer, default=3600)
    muted_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    unmuted_at = db.Column(db.DateTime)

    room = db.relationship('LiveRoom', back_populates='mutes')
    muted_user = db.relationship('User', back_populates='mutes', foreign_keys=[muted_user_id])
    muted_by_user = db.relationship('User', foreign_keys=[muted_by])


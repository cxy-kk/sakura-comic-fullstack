from ..extensions import db
from sqlalchemy.dialects.mysql import LONGTEXT
import datetime

class LiveStream(db.Model):
    __tablename__ = 'sakura_live_stream'
    id = db.Column(db.Integer, primary_key=True)
    room_id = db.Column(db.Integer, db.ForeignKey('sakura_live_room.id'), unique=True, nullable=False)
    stream_key = db.Column(db.String(64), unique=True, nullable=False)
    rtmp_push_url = db.Column(db.String(255), nullable=False)
    rtmp_pull_url = db.Column(db.String(255), nullable=False)
    hls_pull_url = db.Column(db.String(255), nullable=False)
    
    room = db.relationship('LiveRoom', back_populates='stream')
    
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

-- 直播间信息表
CREATE TABLE `sakura_live_room` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `user_id` INT(11) NOT NULL COMMENT '主播用户ID，外键关联 sakura_user',
    `room_name` VARCHAR(100) NOT NULL COMMENT '直播间名称',
    `stream_key` VARCHAR(64) NOT NULL UNIQUE COMMENT '推流密钥，用于推流鉴权',
    `rtmp_push_url` VARCHAR(255) NOT NULL COMMENT 'RTMP 推流地址',
    `rtmp_pull_url` VARCHAR(255) NOT NULL COMMENT 'RTMP 拉流地址',
    `hls_pull_url` VARCHAR(255) NOT NULL COMMENT 'HLS 拉流地址',
    `is_live` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '直播状态 (0: 离线, 1: 直播中)',
    `start_time` DATETIME NULL DEFAULT NULL COMMENT '直播开始时间',
    `end_time` DATETIME NULL DEFAULT NULL COMMENT '直播结束时间',
    `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `stream_key_unique` (`stream_key`),
    INDEX `user_id_idx` (`user_id`),
    CONSTRAINT `fk_live_room_user` FOREIGN KEY (`user_id`) REFERENCES `sakura_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
)
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
;

-- 直播历史记录表 (可选，用于记录每次直播的详情)
CREATE TABLE `sakura_live_history` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `room_id` INT(11) NOT NULL COMMENT '直播间ID',
    `start_time` DATETIME NOT NULL COMMENT '直播开始时间',
    `end_time` DATETIME NULL DEFAULT NULL COMMENT '直播结束时间',
    `duration` INT(11) NULL DEFAULT 0 COMMENT '直播时长（秒）',
    `peak_viewers` INT(11) NULL DEFAULT 0 COMMENT '峰值观看人数',
    PRIMARY KEY (`id`),
    INDEX `room_id_idx` (`room_id`),
    CONSTRAINT `fk_live_history_room` FOREIGN KEY (`room_id`) REFERENCES `sakura_live_room` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
)
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
;

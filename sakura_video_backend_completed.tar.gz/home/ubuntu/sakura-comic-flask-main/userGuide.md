# Sakura Video 后端项目运行指南

本项目基于 Python Flask 框架，使用 MySQL 数据库，并集成了直播功能。

## 一、环境准备

1.  **操作系统**：Linux (推荐 Ubuntu/Debian) 或 macOS。
2.  **Python**：Python 3.8+ (本项目在 Python 3.11 环境下调试通过)。
3.  **数据库**：MySQL 5.7+。

## 二、安装依赖

### 1. 安装系统依赖

```bash
# 安装 MySQL 服务器和客户端
sudo apt-get update
sudo apt-get install -y mysql-server mysql-client
# 启动 MySQL 服务
sudo systemctl start mysql
```

### 2. 安装 Python 依赖

进入项目根目录：

```bash
cd /home/ubuntu/sakura-comic-flask-main
# 安装所有 Python 依赖
pip3 install -r requirements.txt
# 由于 requirements.txt 中的部分版本可能与 Python 3.11 存在兼容性问题，
# 建议手动安装或升级以下关键库：
pip3 install flask_sqlalchemy flask_wtf flask_cors flask_httpauth flask_apscheduler authlib pymysql
```

## 三、数据库配置与初始化

### 1. 创建数据库和用户

以 root 用户身份登录 MySQL，并执行以下命令创建数据库和用户：

```sql
# 登录 MySQL
sudo mysql

# 创建数据库
CREATE DATABASE IF NOT EXISTS sakura_video_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

# 创建用户并授权 (密码为 sakura_password)
CREATE USER 'sakura_user'@'localhost' IDENTIFIED BY 'sakura_password';
GRANT ALL PRIVILEGES ON sakura_video_db.* TO 'sakura_user'@'localhost';
FLUSH PRIVILEGES;

# 退出 MySQL
EXIT;
```

### 2. 导入表结构

本项目已包含所有必要的表结构文件。

```bash
# 导入基础表结构
sudo mysql sakura_video_db < config/create_table_clean.sql
# 导入直播相关表结构
sudo mysql sakura_video_db < config/create_live_table.sql
```

### 3. 检查配置

数据库连接信息已在 `config/config.yaml` 中配置为：

```yaml
SQLALCHEMY_DATABASE_URI: 'mysql+pymysql://sakura_user:sakura_password@localhost:3306/sakura_video_db'
```

## 四、运行后端项目

在项目根目录下执行：

```bash
python3 run.py
```

项目默认运行在 `http://127.0.0.1:5000`。

## 五、直播功能说明 (附加题)

本项目集成了基于 **Nginx-RTMP** 方案的直播功能。

### 1. 核心技术点

*   **流媒体服务器**：需要额外搭建 Nginx-RTMP 模块。
*   **推流地址**：通过 API `/api/v1/live/stream/status` 获取 `rtmp_push_url`。
*   **拉流地址**：通过 API `/api/v1/live/rooms/{room_id}` 获取 `rtmp_pull_url` 和 `hls_pull_url`。
*   **回调机制**：后端 API `/api/v1/live/callback/<action>` 用于接收 Nginx-RTMP 的 `on_publish` 和 `on_done` 回调，以更新直播间状态。

### 2. 直播 API 流程

1.  **创建直播间**：`POST /api/v1/live/rooms` (需要用户认证)。
2.  **获取推流信息**：`GET /api/v1/live/stream/status` (获取 `rtmp_push_url` 和 `stream_key`)。
3.  **推流**：使用 OBS 等推流工具，将视频流推送到 `rtmp_push_url`。
4.  **状态更新**：Nginx-RTMP 服务器通过回调 API 通知后端直播开始 (`on_publish`)。
5.  **观看**：前端使用 `hls_pull_url` 或 `rtmp_pull_url` 进行拉流观看。

### 3. 前端测试文件

您可以使用项目根目录下的 `live_test.html` 文件来测试直播相关的 API 接口连通性。

---
**注意：** 由于沙箱环境限制，本项目未实际安装 Nginx-RTMP 服务器。在实际部署中，您需要：
1.  安装 Nginx 并编译 `nginx-rtmp-module` 模块。
2.  配置 Nginx，将 `on_publish` 和 `on_done` 回调指向本项目的 `/api/v1/live/callback/<action>` 接口。
3.  将 `live.py` 中的 `RTMP_SERVER` 和 `HLS_SERVER` 地址修改为您的实际服务器地址。
